import sys
import socket
import threading
import re
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QComboBox, QTextBrowser, QMessageBox
from PyQt5.QtCore import pyqtSignal, QThread

class ClientThread(QThread):
    message_received = pyqtSignal(str)

    def __init__(self, socket):
        super().__init__()
        self.client_socket = socket

    def run(self):
        while True:
            try:
                message = self.client_socket.recv(1024).decode()
                self.message_received.emit(message)
            except OSError:
                break

class LoginWidget(QWidget):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        label_username = QLabel("Identité:")
        self.entry_username = QLineEdit()
        layout.addWidget(label_username)
        layout.addWidget(self.entry_username)

        label_password = QLabel("Mot de passe:")
        self.entry_password = QLineEdit()
        self.entry_password.setEchoMode(QLineEdit.Password)
        layout.addWidget(label_password)
        layout.addWidget(self.entry_password)

        label_alias = QLabel("Alias:")
        self.entry_alias = QLineEdit()
        layout.addWidget(label_alias)
        layout.addWidget(self.entry_alias)

        button_login = QPushButton("Se connecter")
        button_login.clicked.connect(self.login)
        layout.addWidget(button_login)

        self.setLayout(layout)

        self.setStyleSheet("""
            QWidget {
                background-color: #2C3E50;
                color: #ECF0F1;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            QLabel {
                color: #ECF0F1;
                font-size: 14px;
            }
            QLineEdit {
                background-color: #34495E;
                color: #ECF0F1;
                border: 1px solid #2C3E50;
                border-radius: 4px;
                padding: 8px;
            }
            QPushButton {
                background-color: #3498DB;
                color: #ECF0F1;
                border: none;
                padding: 10px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #2980B9;
            }
        """)

    def login(self):
        self.client.username = self.entry_username.text()
        password = self.entry_password.text()
        alias = self.entry_alias.text()

        if not self.is_valid_username(self.client.username) or not self.is_valid_password(password):
            QMessageBox.critical(self, "Erreur", "Nom d'utilisateur ou mot de passe incorrect.")
            return

        registration_data = f"{self.client.username}{alias}"
        self.client.client_socket.send(registration_data.encode())
        self.client.request_join_channel("Général")
        self.client.show_main_window()
        self.close()

    def is_valid_username(self, username):
        return re.match("^[a-zA-Z0-9]+$", username) is not None

    def is_valid_password(self, password):
        return password == "root"

class ChannelChatWindow(QWidget):
    def __init__(self, client, channel_name):
        super().__init__()
        self.client = client
        self.channel_name = channel_name
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(f"Salon {self.channel_name}")
        self.setGeometry(100, 100, 400, 300)

        self.layout = QVBoxLayout()

        self.label_current_channel = QLabel(f"Salon actuel: {self.channel_name}")
        self.layout.addWidget(self.label_current_channel)

        self.label_users = QLabel("Utilisateurs connectés:")
        self.layout.addWidget(self.label_users)

        self.text_browser = QTextBrowser()
        self.layout.addWidget(self.text_browser)

        self.entry_message = QLineEdit()
        self.entry_message.returnPressed.connect(self.send_message)
        self.layout.addWidget(self.entry_message)

        self.button_send = QPushButton("Envoyer")
        self.button_send.clicked.connect(self.send_message)
        self.layout.addWidget(self.button_send)

        self.button_disconnect = QPushButton("Déconnexion")
        self.button_disconnect.clicked.connect(self.disconnect)
        self.layout.addWidget(self.button_disconnect)

        self.setLayout(self.layout)

        self.setStyleSheet("""
            QWidget {
                background-color: #2C3E50;
                color: #ECF0F1;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            QLabel {
                color: #ECF0F1;
                font-size: 14px;
            }
            QTextBrowser, QLineEdit {
                background-color: #34495E;
                color: #ECF0F1;
                border: 1px solid #2C3E50;
                border-radius: 4px;
                padding: 8px;
            }
            QPushButton {
                background-color: #3498DB;
                color: #ECF0F1;
                border: none;
                padding: 10px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #2980B9;
            }
        """)

    def send_message(self):
        message = self.entry_message.text()
        if message:
            self.client.client_socket.send(f"{message}".encode())
            self.entry_message.clear()

    def handle_message(self, message):
        if message.startswith("USERS|"):
            _, users = message.split("|")
            users_list = users.split(",")
            self.update_users_label(users_list)
        else:
            self.text_browser.append(message)

    def update_users_label(self, users_list):
        users_text = ", ".join(users_list)
        self.label_users.setText(f"Utilisateurs connectés: {users_text}")

    def disconnect(self):
        self.client.disconnect_from_server()

class ChatClient(QWidget):
    def __init__(self):
        super().__init__()

        self.username = None
        self.current_channel_name = "Général"
        self.channels = ["Général", "Blabla", "Comptabilité", "Informatique", "Marketing"]
        self.channel_windows = {}
        self.current_channel_window = None

        self.init_ui()

        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect(('127.0.0.1', 25000))

        self.client_thread = ClientThread(self.client_socket)
        self.client_thread.message_received.connect(self.handle_message)
        self.client_thread.start()

        self.login_widget = LoginWidget(self)

    def init_ui(self):
        layout = QVBoxLayout()

        label_channel = QLabel("Choisir un salon:")
        self.combo_box_channel = QComboBox()
        self.combo_box_channel.addItems(self.channels)
        self.combo_box_channel.currentIndexChanged.connect(self.change_channel)
        layout.addWidget(label_channel)
        layout.addWidget(self.combo_box_channel)

        show_channel_button = QPushButton("Afficher le salon")
        show_channel_button.clicked.connect(self.show_channel)
        layout.addWidget(show_channel_button)

        self.button_disconnect = QPushButton("Déconnexion")
        self.button_disconnect.clicked.connect(self.disconnect_from_server)
        layout.addWidget(self.button_disconnect)

        self.setLayout(layout)

        self.setStyleSheet("""
            QWidget {
                background-color: #2C3E50;
                color: #ECF0F1;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            QLabel {
                color: #ECF0F1;
                font-size: 50px;
            }
            QComboBox, QPushButton {
                background-color: #3498DB;
                color: #ECF0F1;
                border: none;
                padding: 15px;
                border-radius: 10px;
            }
            QComboBox:hover, QPushButton:hover {
                background-color: #2980B9;
            }
        """)

    def show_main_window(self):
        self.login_widget.close()
        self.show()

    def change_channel(self):
        selected_channel = self.combo_box_channel.currentText()
        self.current_channel_name = selected_channel
        if selected_channel not in self.channel_windows:
            self.channel_windows[selected_channel] = ChannelChatWindow(self, selected_channel)
        for channel_name, window in self.channel_windows.items():
            if channel_name == self.current_channel_name:
                window.show()
            else:
                window.hide()

    def show_channel(self):
        pass

    def request_join_channel(self, channel):
        join_request = f"JOIN|{channel}|{self.username}"
        self.client_socket.send(join_request.encode())

    def handle_message(self, message):
        if message.startswith("USERS|"):
            _, users = message.split("|")
            users_list = users.split(",")
            if self.current_channel_name in self.channel_windows:
                self.channel_windows[self.current_channel_name].handle_message(message)
                self.channel_windows[self.current_channel_name].update_users_label(users_list)
        elif self.current_channel_name in self.channel_windows:
            self.channel_windows[self.current_channel_name].handle_message(message)

    def disconnect_from_server(self):
        self.client_thread.terminate()
        self.client_socket.close()
        sys.exit(app.exec_())

if __name__ == '__main__':
    app = QApplication(sys.argv)
    client = ChatClient()
    client.login_widget.show()
    sys.exit(app.exec_())
