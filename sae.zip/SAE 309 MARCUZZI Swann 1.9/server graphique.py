import sys
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QTextEdit,
    QVBoxLayout,
    QPushButton,
    QWidget,
    QInputDialog,
    QLabel,
)
from PyQt5.QtCore import Qt, QTimer
import socket
import threading
import mysql.connector


class ServerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.clients = {}
        self.server_socket = None
        self.server_running = False
        self.db_connection = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="toto123",
            database="test2",
        )
        self.db_cursor = self.db_connection.cursor()
        self.db_cursor.execute(
            '''
            CREATE TABLE IF NOT EXISTS clients (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(255),
                ip_address VARCHAR(15),
                kick_expiry DATETIME,
                ban_expiry DATETIME,
                kicked BOOLEAN DEFAULT False,
                banned BOOLEAN DEFAULT False
            )
        '''
        )

        self.db_cursor.execute(
            '''
            CREATE TABLE IF NOT EXISTS message309 (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sender_username VARCHAR(255),
                message_text TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        '''
        )

        self.db_connection.commit()
        self.init_ui()

        self.kick_timer = QTimer(self)
        self.kick_timer.timeout.connect(self.kick_timer_expired)
        self.kick_duration = 0

        self.ban_timer = QTimer(self)
        self.ban_timer.timeout.connect(self.ban_timer_expired)
        self.ban_duration = 0

    def init_ui(self):
        self.setWindowTitle("Server Chat")
        self.setGeometry(100, 100, 600, 400)

        self.text_edit = QTextEdit(self)
        self.text_edit.setReadOnly(True)

        self.client_list_label = QLabel("Clients connectés:", self)
        self.client_list_label.setAlignment(Qt.AlignCenter)

        self.start_button = QPushButton("Start Server", self)
        self.start_button.clicked.connect(self.start_server)

        self.stop_button = QPushButton("Stop Server", self)
        self.stop_button.clicked.connect(self.stop_server)
        self.stop_button.setEnabled(False)

        self.kick_button = QPushButton("Kick clients", self)
        self.kick_button.clicked.connect(self.kick_user)
        self.kick_button.setEnabled(False)

        self.ban_button = QPushButton("Ban clients", self)
        self.ban_button.clicked.connect(self.ban_user)
        self.ban_button.setEnabled(False)

        layout = QVBoxLayout()
        layout.addWidget(self.text_edit)
        layout.addWidget(self.client_list_label)
        layout.addWidget(self.start_button)
        layout.addWidget(self.stop_button)
        layout.addWidget(self.kick_button)
        layout.addWidget(self.ban_button)

        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        self.setStyleSheet('''
            QMainWindow {
                background-color: #f0f0f0;
            }
            QTextEdit, QLabel {
                background-color: #ffffff;
                color: #333333;
                border: 1px solid #cccccc;
                border-radius: 5px;
                padding: 5px;
                margin: 5px;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                cursor: pointer;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        ''')

    def start_server(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind(('0.0.0.0', 25000))
        self.server_socket.listen()

        self.server_running = True
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.kick_button.setEnabled(True)
        self.ban_button.setEnabled(True)

        self.print_message("Le serveur est en attente de connexions...")

        server_thread = threading.Thread(target=self.accept_connections)
        server_thread.start()

    def accept_connections(self):
        while self.server_running:
            client_socket, client_address = self.server_socket.accept()
            client_thread = threading.Thread(
                target=self.handle_client, args=(client_socket, client_address)
            )
            client_thread.start()

    def stop_server(self):
        self.server_running = False
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.kick_button.setEnabled(False)
        self.ban_button.setEnabled(False)
        if self.server_socket:
            self.server_socket.close()
        self.print_message("Le serveur a été arrêté.")

    def handle_client(self, client_socket, client_address):
        try:
            client_username = client_socket.recv(1024).decode()
            self.insert_client(client_username, client_address[0])
            self.clients[client_username] = {
                "socket": client_socket,
                "kicked": False,
                "banned": False,
            }
            self.broadcast(f"{client_username} a rejoint la conversation.\n")
            while self.server_running:
                message = client_socket.recv(1024)
                if not message:
                    break
                self.broadcast(f"{client_username}: {message.decode()}")
                self.insert_message(client_username, message.decode())
                self.update_client_list()
        except Exception as e:
            self.print_message(f"Erreur avec le client {client_address}: {e}")
        finally:
            if client_username in self.clients:
                del self.clients[client_username]
                self.broadcast(f"{client_username} a quitté la conversation.\n")
                self.update_client_list()
            client_socket.close()

    def insert_client(self, username, ip_address):
        self.db_cursor.execute(
            "INSERT INTO clients (username, ip_address) VALUES (%s, %s)",
            (username, ip_address),
        )
        self.db_connection.commit()

    def insert_message(self, sender_username, message_text):
        self.db_cursor.execute(
            "INSERT INTO message309 (sender_username, message_text) VALUES (%s, %s)",
            (sender_username, message_text),
        )
        self.db_connection.commit()

    def kick_user(self):
        selected_user, ok = QInputDialog.getItem(
            self,
            "Kick User",
            "Sélectionnez le client que vous voulez kick:",
            self.clients.keys(),
            0,
            False,
        )
        if ok:
            duration, ok = QInputDialog.getInt(
                self,
                "Kick Duration",
                "Entrez la durée du kick en secondes:",
                30,
                1,
                3600,
                1,
            )
            if ok:
                self.kick_duration = duration * 1000
                client_info = self.clients.get(selected_user)
                if client_info and not client_info["kicked"]:
                    client_socket = client_info["socket"]
                    kick_message = "Vous ne pouvez pas envoyer de messages pour la durée spécifiée."
                    client_socket.send(kick_message.encode())
                    self.clients[selected_user]["kicked"] = True
                    self.kick_timer.singleShot(
                        self.kick_duration, lambda: self.unblock_user(selected_user)
                    )

    def unblock_user(self, username):
        if username in self.clients:
            self.clients[username]["kicked"] = False
            self.broadcast(f"{username} est autorisé à envoyer des messages.\n")

    def kick_timer_expired(self):
        self.kick_timer.stop()
        self.broadcast("Le temps d'expulsion est écoulé.\n")

    def ban_user(self):
        selected_user, ok = QInputDialog.getItem(
            self,
            "Ban User",
            "Sélectionnez le client que vous voulez bannir:",
            self.clients.keys(),
            0,
            False,
        )
        if ok:
            duration, ok = QInputDialog.getInt(
                self,
                "Ban Duration",
                "Entrez la durée du ban en secondes:",
                300,
                1,
                3600,
                1,
            )
            if ok:
                self.ban_duration = duration * 1000
                client_info = self.clients.get(selected_user)
                if client_info and not client_info["banned"]:
                    client_socket = client_info["socket"]
                    ban_message = "Vous avez été banni par le serveur."
                    client_socket.send(ban_message.encode())
                    self.clients[selected_user]["banned"] = True
                    self.ban_timer.singleShot(
                        self.ban_duration,
                        lambda: self.disconnect_user(selected_user),
                    )

    def disconnect_user(self, username):
        if username in self.clients:
            client_socket = self.clients[username]["socket"]
            client_socket.close()
            del self.clients[username]
            self.broadcast(
                f"{username} a été banni et déconnecté par le serveur.\n"
            )
            self.update_client_list()

    def ban_timer_expired(self):
        self.ban_timer.stop()
        self.broadcast("Le temps de bannissement est écoulé.\n")

    def broadcast(self, message):
        for client_info in self.clients.values():
            try:
                client_socket = client_info["socket"]
                if not client_info["kicked"] and not client_info["banned"]:
                    client_socket.send(message.encode())
            except socket.error:
                pass

    def update_client_list(self):
        client_list = ", ".join(
            client
            for client, info in self.clients.items()
            if not info["kicked"] and not info["banned"]
        )
        self.client_list_label.setText(f"Clients connectés: {client_list}")

    def print_message(self, message):
        self.text_edit.append(message)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ServerWindow()
    window.show()
    sys.exit(app.exec_())
